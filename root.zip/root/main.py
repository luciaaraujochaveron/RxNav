from root.get_drug_data import get_drug_data
from root.get_drug_data_fuzzy_search import get_drug_data_fuzzy_search

def choose_search_mode():
    print("=" * 40)
    print("  RxNav Drug Data Retrieval Tool")
    print("=" * 40)
    print("Select a search mode:")
    print("  [1] Exact Search of the drug name")
    print("  [2] Fuzzy Search of the drug name")
    print("-" * 40)

    while True:
        choice = input("Enter your choice (1 or 2): ").strip()
        if choice == "1":
            return get_drug_data
        elif choice == "2":
            return get_drug_data_fuzzy_search
        else:
            print("Invalid input. Please enter 1 or 2.")

def main():
    search_fn = choose_search_mode()
    print("-" * 40)
    drug_name = input("Enter the drug name: ").strip()
    print("-" * 40)
    print("Drug data retrieval in progress...")
    print("-" * 40)
    search_fn(drug_name)
    print("-" * 40)
    print("**Drug data retrieval completed!**")